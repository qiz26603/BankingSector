public class HistoryTrans {
    private int ID = 0, Sodutk = 0, Sotiengd = 0, Soduafter = 0, CVV = 0;
    String cardNum = "", name = "", cardnumth = "", nameth = "", date = "";
    public HistoryTrans(String cardNum, String name, int ID, String cardnumth, String nameth, int sodutk, int sotiengd, int soduafter, String date, int cvv) {
        this.cardNum = cardNum;
        this.name = name;
        this.ID = ID;
        this.cardnumth = cardnumth;
        this.nameth = nameth;
        this.Sodutk = sodutk;
        this.Sotiengd = sotiengd;
        this.Soduafter = soduafter;
        this.date = date;
        this.CVV = cvv;
    }
    public int getID() {
        return ID;
    }
    public void setID(int ID) {
        this.ID = ID;
    }
    public int getSodutk() {
        return Sodutk;
    }
    public void setSodutk(int sodutk) {
        Sodutk = sodutk;
    }
    public int getSotiengd() {
        return Sotiengd;
    }
    public void setSotiengd(int sotiengd) {
        Sotiengd = sotiengd;
    }
    public int getSoduafter() {
        return Soduafter;
    }
    public void setSoduafter(int soduafter) {
        Soduafter = soduafter;
    }
    public int getCVV() {
        return CVV;
    }
    public void setCVV(int CVV) {
        this.CVV = CVV;
    }
    public String getCardNum() {
        return cardNum;
    }
    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCardnumth() {
        return cardnumth;
    }
    public void setCardnumth(String cardnumth) {
        this.cardnumth = cardnumth;
    }
    public String getNameth() {
        return nameth;
    }
    public void setNameth(String nameth) {
        this.nameth = nameth;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
}
