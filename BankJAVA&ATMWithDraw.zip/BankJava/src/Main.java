import java.io.IOException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);
        The Card = new The("","","","",0, 0);
        GiaoDich tran = new GiaoDich("",0,"","",0,0,0,0);
        HistoryTrans History = new HistoryTrans("","",0,"","",0,0,0,"",0);
        Funtion a = new Funtion();
        a.Reseted();
        int choose = 0;
        KeyPair keyPair = a.generateKeyPair();
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();
        do {
            System.out.println(" --------------------------- BIDV XIN CHÀO QUÝ KHÁCH -------------------------- ");
            System.out.println(" -------------------- MỜI BẠN CHỌN THAO TÁC MUỐN THỰC HIỆN -------------------- ");
            System.out.println(" |                   1. KHỞI TẠO THẺ THANH TOÁN QUỐC TẾ MỚI                   | ");
            System.out.println(" |                   2. KHỞI TẠO GIAO DỊCH MỚI                                | ");
            System.out.println(" |                   3. XEM LỊCH SỬ GIAO DỊCH                                 | ");
            System.out.println(" |                   0. THOÁT                                                 | ");
            System.out.println(" ------------------------------------------------------------------------------ ");
            choose = in.nextInt();
            switch (choose) {
                case 1: {
                    a.Input(Card, publicKey);
                    in.nextLine();
                    System.out.println("\nNhấn Enter để tiếp tục. ");
                    in.nextLine();
                    break;
                }
                case 2: {
                    a.Transaction(tran, publicKey, privateKey);
                    in.nextLine();
                    System.out.println("\nNhấn Enter để tiếp tục. ");
                    in.nextLine();
                    break;
                }
                case 3: {
                    a.HistoryTrans(History, privateKey);
                    in.nextLine();
                    System.out.println("\nNhấn Enter để tiếp tục. ");
                    in.nextLine();
                    break;
                }
                case 0: {
                    System.out.println(" ~~~~~~~~~~~~~~~~ THOÁT ~~~~~~~~~~~~~~~~~~ ");
                    System.out.println("Đã thoát chọn thao tác muốn thực hiện tại BIDV. ");
                    break;
                }
                default: {
                    System.out.println("Bạn đã chọn thao tác không hợp lệ. Vui lòng chọn thao tác lại. ");
                    break;
                }
            }
        } while (choose != 0);
    }
}