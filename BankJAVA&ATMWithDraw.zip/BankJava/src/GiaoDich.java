public class GiaoDich {

    private int ID = 0, Sodutk = 0, Sotiengd = 0, Soduafter = 0, CVV = 0;
    String cardNum = "", name = "", cardnumber = "", date = "";
    public GiaoDich(String cardNum, int ID, String cardnumTh, String name, int sodutk, int sotiengd, int soduafter, int cvv) {
        this.cardNum = cardNum;
        this.ID = ID;
        this.cardnumber = cardnumTh;
        this.name = name;
        this.Sodutk = sodutk;
        this.Sotiengd = sotiengd;
        this.Soduafter = soduafter;
        this.CVV = cvv;
    }
    public String getCardNum() {
        return cardNum;
    }
    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }
    public int getID() {
        return ID;
    }
    public void setID(int ID) {
        this.ID = ID;
    }
    public int getSodutk() {
        return Sodutk;
    }
    public void setSodutk(int sodutk) {
        Sodutk = sodutk;
    }
    public int getSotiengd() {
        return Sotiengd;
    }
    public void setSotiengd(int sotiengd) {
        Sotiengd = sotiengd;
    }
    public int getSoduafter() {
        return Soduafter;
    }
    public void setSoduafter(int soduafter) {
        Soduafter = soduafter;
    }
    public int getCVV() {
        return CVV;
    }
    public void setCVV(int CVV) {
        this.CVV = CVV;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCardnumber() {
        return cardnumber;
    }
    public void setCardnumber(String cardnumber) {
        this.cardnumber = cardnumber;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
}
