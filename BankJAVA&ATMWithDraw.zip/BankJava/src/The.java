import java.util.Scanner;

public class The{
    private String card_organize = "", card_type = "", name = "", card_number = "";
    private int CVV = 0, sodu = 0;
//    Scanner sc = new Scanner(System.in);
    public The(String card_type, String card_organize, String name, String card_number, int CVV, int sodu)
    {
        this.card_type = card_type;
        this.card_organize = card_organize;
        this.name = name;
        this.card_number = card_number;
        this.CVV = CVV;
        this.sodu = sodu;
    }
    public String getCard_type() {
        return card_type;
    }
    public void setCard_type(String card_type) {
        this.card_type = card_type;
    }
    public String getCard_organize() {
        return card_organize;
    }
    public void setCard_organize(String card_organize) {
        this.card_organize = card_organize;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCard_number() {
        return card_number;
    }
    public void setCard_number(String card_number) {
        this.card_number = card_number;
    }
    public int getCVV() {
        return CVV;
    }
    public void setCVV(int CVV) {
        this.CVV = CVV;
    }
    public int getSodu() {
        return sodu;
    }
    public void setSodu(int sodu) {
        this.sodu = sodu;
    }
}
