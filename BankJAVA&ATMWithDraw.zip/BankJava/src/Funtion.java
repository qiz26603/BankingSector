import javax.crypto.Cipher;
import java.io.*;
import java.security.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
public class Funtion {
    public boolean CheckCardType(int choose_organize)
    {
        if (choose_organize >= 1 && choose_organize <= 2)
        {
            return true;
        }
        else {
            System.out.println("Mời bạn chọn lại tổ chức phát hành thẻ. Vui lòng chọn hợp lệ. ");
            return false;
        }
    }
    private String CardType(int choose_organize)
    {
        String the = "";
        if (choose_organize == 1)
        {
            the = "Visa";
        }
        else {
            the = "Mastercard";
        }
        return the;
    }
    private boolean CheckName(String name)
    {
        if (name.isEmpty())
        {
            System.out.println("Họ và tên chưa được nhập. Vui lòng nhập lại. ");
            return false;
        }

            if (name.charAt(0) == ' ')
            {
                System.out.println("Họ và tên không được có dấu cách ở vị trí đầu tiên. Vui lòng nhập lại. ");
                return false;
            }
            if (name.charAt(name.length() - 1) == ' ')
            {
                System.out.println("Họ và tên không được có dấu cách ở vị trí cuối cùng. Vui lòng nhập lại. ");
                return false;
            }
            for (int i = 0; i < name.length(); i++)
            {
                if(name.charAt(i) >= 'a' && name.charAt(i) <= 'z' || name.charAt(i) >= 'A' && name.charAt(i) <= 'Z' || name.charAt(i) == ' ')
                {
                    continue;
                }
                else
                {
                    System.out.println("Tên không được chứa ký tự khác chữ cái. Vui lòng nhập lại. ");
                    return false;
                }
            }
            return true;

    }
    private boolean CheckLuhnAlgorithm(String stk, String i)
    {
        stk = stk + i;
//        System.out.println(stk);
//        String stk_str, last_stk = "", laststk = "";
//        int stk_inte = 0, chuc = 0, dvi = 0, last_stkinter = 0, sum_stk = 0, mod_laststk = 0, dem = 0;
////        int tk = Integer.parseInt(stk);
//        for(int j = 0; j < stk.length(); j++)
//        {
//            dem++;
//            if (j % 2 == 0)
//            {
//                stk_str = stk.substring(j,j+1);
//                stk_inte = Integer.parseInt(stk_str)*2;
//                if (stk_inte > 9)
//                {
//                    chuc = stk_inte/10;
//                    dvi = stk_inte%10;
//                    last_stkinter = chuc + dvi;
//                }
//                last_stk = last_stk + Integer.toString(last_stkinter);
//            }
//            else {
//                last_stk = last_stk + stk.charAt(j);
//            }
//        }
//        System.out.println('\"' + last_stk + '\"');
//        //laststk = Integer.parseInt(last_stk);
//        int a = 0;
//        while (a >= dem) {
//            //String builder khúc này
//            laststk = last_stk.charAt(a) + "";
//            sum_stk += Integer.parseInt(laststk);
//            a++;
//        }
//        System.out.println(sum_stk);
//        if (sum_stk % 10 == 0)
//        {
//            return true;
//        }
//        else
//        {
//            return false;
//        }
        int nDigits = stk.length();
        int nSum = 0;
        boolean isSecond = false;
        for (int j = nDigits - 1; j >= 0; j--)
        {
            int d = stk.charAt(j) - '0';
            if (isSecond == true)
                d = d * 2;
            nSum += d / 10;
            nSum += d % 10;
            isSecond = !isSecond;
        }
        return (nSum % 10 == 0);
    }
    private boolean CheckLuhnAlgorithm1(String stk)
    {
//        System.out.println(stk);
//        String stk_str, last_stk = "", laststk = "";
//        int stk_inte = 0, chuc = 0, dvi = 0, last_stkinter = 0, sum_stk = 0, mod_laststk = 0, dem = 0;
////        int tk = Integer.parseInt(stk);
//        for(int j = 0; j < stk.length(); j++)
//        {
//            dem++;
//            if (j % 2 == 0)
//            {
//                stk_str = stk.substring(j,j+1);
//                stk_inte = Integer.parseInt(stk_str)*2;
//                if (stk_inte > 9)
//                {
//                    chuc = stk_inte/10;
//                    dvi = stk_inte%10;
//                    last_stkinter = chuc + dvi;
//                }
//                last_stk = last_stk + Integer.toString(last_stkinter);
//            }
//            else {
//                last_stk = last_stk + stk.charAt(j);
//            }
//        }
//        System.out.println('\"' + last_stk + '\"');
//        //laststk = Integer.parseInt(last_stk);
//        int a = 0;
//        while (a >= dem) {
//            //String builder khúc này
//            laststk = last_stk.charAt(a) + "";
//            sum_stk += Integer.parseInt(laststk);
//            a++;
//        }
//        System.out.println(sum_stk);
//        if (sum_stk % 10 == 0)
//        {
//            return true;
//        }
//        else
//        {
//            return false;
//        }
        int nDigits = stk.length();
        int nSum = 0;
        boolean isSecond = false;
        for (int j = nDigits - 1; j >= 0; j--)
        {
            int d = stk.charAt(j) - '0';
            if (isSecond == true)
                d = d * 2;
            nSum += d / 10;
            nSum += d % 10;
            isSecond = !isSecond;
        }
        return (nSum % 10 == 0);
    }
    public String PrintCurrency(int money)
    {   //1,000,000,000 VND
        String moneystring = String.valueOf(money);
        StringBuilder sb = new StringBuilder(moneystring);
        int comma = 0, locate = 0;
        comma = (moneystring.length() - 1)/3;
        locate = moneystring.length() - comma * 3;
        while (comma > 0)
        {
            sb = sb.insert(locate, ",");
            locate += 4;
            comma --;
        }
        moneystring = sb.toString();
        return moneystring + " VND";
    }
    private boolean CheckMoney(int money, int sodu)
    {
        if (money < 10000)
        {
            System.out.println("Số tiền giao dịch không hợp lệ (<10,000 VND)");
            return false;
        }
        else if ((money % 10000) != 0)
        {
            System.out.println("Số tiền giao dịch không hợp lệ (Không phải là bội số của 10,000 VND)");
            return false;
        }
        else if ((sodu - money) < 50000)
        {
            System.out.println("Số tiền giao dịch không hợp lệ (Số dư không đủ (Vui lòng chú ý: Số dư tối thiểu còn lại phải là 50,000 VND)). ");
            return false;
        }
        else
        {
            return true;
        }
    }
    private static final String ALGORITHM = "RSA";
    public static KeyPair generateKeyPair() throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(ALGORITHM);
        SecureRandom secureRandom = new SecureRandom();
        keyPairGenerator.initialize(2048, secureRandom);
        return keyPairGenerator.generateKeyPair();
    }
    public static byte[] encrypt(String message, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        return cipher.doFinal(message.getBytes());
    }
    public static String decrypt(byte[] encryptedMessage, PrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] decryptedBytes = cipher.doFinal(encryptedMessage);
        return new String(decryptedBytes);
    }
    public static String bytesToHex(byte[] bytes)
    {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }
    public static byte[] hexToBytes(String hexString) {
        int length = hexString.length();
        byte[] bytes = new byte[length / 2];
        for (int i = 0; i < length; i += 2) {
            bytes[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
                    + Character.digit(hexString.charAt(i + 1), 16));
        } return bytes;
    }
    public static ArrayList<The> readCardFile(String filename, PrivateKey privateKey) {
        ArrayList<The> cardList = new ArrayList<>();
        try (BufferedReader bfr = new BufferedReader(new FileReader(filename))){
            String line;
            while ((line = bfr.readLine()) != null) {
                String[] data = line.split(",");
                String encryptedCardType = data[0];
                String card_type = decrypt(hexToBytes(encryptedCardType), privateKey);
                String encryptedCardOrganize = data[1];
                String card_organize = decrypt(hexToBytes(encryptedCardOrganize), privateKey);
                String encryptedName = data[2];
                String name = decrypt(hexToBytes(encryptedName), privateKey);
                String encryptedCardNumber = data[3];
                String card_number = decrypt(hexToBytes(encryptedCardNumber), privateKey);
                String encryptedCVV = data[4];
                String decryptedCVV = decrypt(hexToBytes(encryptedCVV), privateKey); 
                int CVV = Integer.parseInt(decryptedCVV);
                String encryptedSodu = data[5];
                String decryptedSodu = decrypt(hexToBytes(encryptedSodu), privateKey);
                int sodu = Integer.parseInt(decryptedSodu);
                The card = new The(card_type, card_organize, name, card_number, CVV, sodu);
                cardList.add(card);
            }
            bfr.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return cardList;
    }
    public static int findCardPosition(ArrayList<The> cardList, String cardNumber) {
        for (int i = 0; i < cardList.size(); i++) {
            The card = cardList.get(i);
            if (card.getCard_number().equals(cardNumber)) {
                return i;
            }
        }
        return -1;
    }
    public static void updateTheFile(ArrayList<The> cardList, String cardNumber, int Soduafter, PublicKey publicKey, String cardnumth,int Sotiengd) throws Exception {
        FileWriter file = new FileWriter("E:\\Documents\\code\\JAVA\\BankJava\\The.txt");
        BufferedWriter writer3 = new BufferedWriter(file);
        writer3.write("");
        writer3.close();
        for (int i = 0; i < cardList.size(); i++) {
            if (cardList.get(i).getCard_number().equals(cardNumber)) {
                cardList.get(i).setSodu(Soduafter);
            }
            if (cardList.get(i).getCard_number().equals(cardnumth))
            {
                int sd = cardList.get(i).getSodu() + Sotiengd;
                cardList.get(i).setSodu(sd);
            }
        }
        for (int i = 0; i < cardList.size(); i++) {
            byte[] encryptedMessage1 = encrypt(cardList.get(i).getCard_type(), publicKey);
            String encryptedCardType = bytesToHex(encryptedMessage1);
            byte[] encryptedMessage2 = encrypt(cardList.get(i).getCard_organize(), publicKey);
            String encryptedCardOrganize = bytesToHex(encryptedMessage2);
            byte[] encryptedMessage3 = encrypt(cardList.get(i).getName(), publicKey);
            String encryptedName = bytesToHex(encryptedMessage3);
            byte[] encryptedMessage4 = encrypt(cardList.get(i).getCard_number(), publicKey);
            String encryptedCardnumber = bytesToHex(encryptedMessage4);
            byte[] encryptedMessage5 = encrypt(Integer.toString(cardList.get(i).getCVV()), publicKey);
            String encryptedCVV = bytesToHex(encryptedMessage5);
            byte[] encryptedMessage6 = encrypt(Integer.toString(cardList.get(i).getSodu()), publicKey);
            String encryptedSodu = bytesToHex(encryptedMessage6);
            FileWriter file1 = new FileWriter("E:\\Documents\\code\\JAVA\\BankJava\\The.txt", true);
            BufferedWriter writer = new BufferedWriter(file1);
            writer.write(encryptedCardType + ',' + encryptedCardOrganize + ',' + encryptedName + ',' + encryptedCardnumber + ',' + encryptedCVV + ',' + encryptedSodu);
            writer.newLine();
            writer.close();
        }
    }
    //    public static ArrayList<GiaoDich> readTransFile(String filename) {
//        ArrayList<GiaoDich> transList = new ArrayList<>();
//        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
//            String line;
//            while ((line = reader.readLine()) != null) {
//                String[] data = line.split(",");
//                String cardNum = data[0];
//                int ID = Integer.parseInt(data[1]);
//                String cardnum_th = data[2];
//                String name = data[3];
//                int sodutk = Integer.parseInt(data[4]);
//                int sotiengd = Integer.parseInt(data[5]);
//                int soduafter = Integer.parseInt(data[6]);
//                String date = data[7];
//                int CVV = Integer.parseInt(data[8]);
//                GiaoDich trans = new GiaoDich(cardNum, ID, cardnum_th, name, sodutk, sotiengd, soduafter, CVV);
//                transList.add(trans);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return transList;
//    }
    public static ArrayList<HistoryTrans> readHistoryFile(String filename, PrivateKey privateKey) {
        ArrayList<HistoryTrans> historyList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                String encryptedCardNum = data[0];
                String cardNum = decrypt(hexToBytes(encryptedCardNum), privateKey);
                String encryptedName = data[1];
                String name = decrypt(hexToBytes(encryptedName), privateKey);
                String encryptedID = data[2];
                String decryptedID = decrypt(hexToBytes(encryptedID), privateKey);
                int ID = Integer.parseInt(decryptedID);
                String encryptedCardnumth = data[3];
                String cardnum_th = decrypt(hexToBytes(encryptedCardnumth), privateKey);
                String encryptedNameth = data[4];
                String nameth = decrypt(hexToBytes(encryptedNameth), privateKey);
                String encryptedSodu = data[5];
                String decryptedSodu = decrypt(hexToBytes(encryptedSodu), privateKey);
                int sodutk = Integer.parseInt(decryptedSodu);
                String encryptedSotiengd = data[6];
                String decryptedSotiengd = decrypt(hexToBytes(encryptedSotiengd), privateKey);
                int sotiengd = Integer.parseInt(decryptedSotiengd);
                String encryptedSoduafter = data[7];
                String decryptedSoduafter = decrypt(hexToBytes(encryptedSoduafter), privateKey);
                int soduafter = Integer.parseInt(decryptedSoduafter);
                String encryptedDate = data[8];
                String date = decrypt(hexToBytes(encryptedDate), privateKey);
                String encryptedCVV = data[9];
                String decryptedCVV = decrypt(hexToBytes(encryptedCVV), privateKey);
                int CVV = Integer.parseInt(decryptedCVV);
                HistoryTrans history = new HistoryTrans(cardNum, name, ID, cardnum_th, nameth, sodutk, sotiengd, soduafter, date, CVV);
                historyList.add(history);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return historyList;
    }
    public void Input(The card, PublicKey publicKey) throws Exception {
        System.out.println(" ~~~~~~~~ KHỞI TẠO THẺ THANH TOÁN QUỐC TẾ ~~~~~~~~~ ");
        Scanner sc = new Scanner(System.in);
        int choose_organize, rand_stk, i, CVV;
        String name = "", stk = "";
        Random rand = new Random();
        card.setCard_type("Thẻ thanh toán quốc tế");
        System.out.println("Loại thẻ: " + card.getCard_type());
        do {
            System.out.println("Chọn tổ chức phát hành thẻ: ");
            System.out.println("1. Thẻ Visa");
            System.out.println("2. Thẻ Mastercard");
            choose_organize = sc.nextInt();
        } while (!CheckCardType(choose_organize));
        card.setCard_organize(CardType(choose_organize));
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Tổ chức phát hành thẻ: " + card.getCard_organize());
        do {
            System.out.println("Nhập họ và tên chủ thẻ: ");
            name = sc1.nextLine();
        } while(!CheckName(name));
        card.setName(name);
        if (card.getCard_organize() == "Visa")
        {
            stk = "427146";
        }
        else {
            stk = "517453";
        }
        rand_stk = rand.nextInt(900000000) + 100000000;
        stk = stk + Integer.toString(rand_stk);
        for (i = 0; i < 10; i++)
        {
            if(CheckLuhnAlgorithm(stk,Integer.toString(i))) {
                stk = stk + Integer.toString(i);
                break;
            }
        }
        card.setCard_number(stk);
        CVV = rand.nextInt(900) + 100;
        card.setCVV(CVV);
        card.setSodu(1000000000);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Loại thẻ: " + card.getCard_type());
        System.out.println("Tổ chức phát hành thẻ: " + card.getCard_organize());
        System.out.println("Họ và tên chủ thẻ: " + card.getName());
        System.out.println("Số thẻ: " + card.getCard_number());
        System.out.println("CVV: " + card.getCVV());
        System.out.println("Số dư: " + PrintCurrency(card.getSodu()));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        byte[] encryptedMessage1 = encrypt(card.getCard_type(), publicKey);
        String encryptedCardType = bytesToHex(encryptedMessage1);
        byte[] encryptedMessage2 = encrypt(card.getCard_organize(), publicKey);
        String encryptedCardOrganize = bytesToHex(encryptedMessage2);
        byte[] encryptedMessage3 = encrypt(card.getName(), publicKey);
        String encryptedName= bytesToHex(encryptedMessage3);
        byte[] encryptedMessage4 = encrypt(card.getCard_number(), publicKey);
        String encryptedCardnumber= bytesToHex(encryptedMessage4);
        byte[] encryptedMessage5 = encrypt(Integer.toString(card.getCVV()), publicKey);
        String encryptedCVV = bytesToHex(encryptedMessage5);
        byte[] encryptedMessage6 = encrypt(Integer.toString(card.getSodu()), publicKey);
        String encryptedSodu = bytesToHex(encryptedMessage6);
        FileWriter file = new FileWriter("E:\\Documents\\code\\JAVA\\BankJava\\The.txt", true);
        BufferedWriter writer = new BufferedWriter(file);
        writer.write(encryptedCardType + ',' + encryptedCardOrganize + ',' + encryptedName + ',' + encryptedCardnumber + ',' + encryptedCVV + ',' + encryptedSodu);
        writer.newLine();
        writer.close();
        System.out.println("Tạo thẻ thanh toán quốc tế thành công. ");
    }
    public void Transaction(GiaoDich trans, PublicKey publicKey, PrivateKey privateKey) throws Exception {
        System.out.println(" ~~~~~~~~~~~~~~~ KHỞI TẠO GIAO DỊCH ~~~~~~~~~~~~~~~~~~ ");
        Scanner inp = new Scanner(System.in);
        Random rand = new Random();
        String chuthe = "", nameth = "", stkth = "", date = "";
        int id = 0, gd_money = 0;
        id = rand.nextInt(900000000) + 100000000;
        trans.setID(id);
        ArrayList<The> cardList = readCardFile("E:\\Documents\\code\\JAVA\\BankJava\\The.txt", privateKey);
        String cardNumber = "";
        int position = 0;
        do {
            System.out.print("Nhập số thẻ của chủ thẻ: ");
            cardNumber = inp.nextLine();
            position = findCardPosition(cardList, cardNumber);
        } while (position == -1);
        The card = cardList.get(position);
        System.out.println("Tổ chức phát hành thẻ: " + card.getCard_organize());
        trans.setCardNum(cardNumber);
        System.out.println("Chủ thẻ: " + card.getName());
        chuthe = card.getName();
        System.out.println("Số dư: " + PrintCurrency(card.getSodu()));
        trans.setSodutk(card.getSodu());
        System.out.println("Số CVV: " + card.getCVV());
        trans.setCVV(card.getCVV());
        System.out.println("ID giao dich: " + trans.getID());
        do {
            System.out.println("Nhập số thẻ thụ hưởng: ");
            stkth = inp.nextLine();
        } while(stkth.length() != 16 || (!CheckLuhnAlgorithm1(stkth)));
        trans.setCardnumber(stkth);
        do {
            System.out.println("Nhập họ và tên người thụ hưởng: ");
            nameth = inp.nextLine();
        } while(!CheckName(nameth));
        trans.setName(nameth);
        do {
            System.out.println("Nhập số tiền giao dịch: ");
            gd_money = inp.nextInt();
        } while(!CheckMoney(gd_money, trans.getSodutk()));
        trans.setSotiengd(gd_money);
        trans.setSoduafter(trans.getSodutk() - gd_money);
        Date day = new Date();
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy; HH:mm:ss");
        date = df.format(day);
        trans.setDate(date);
        byte[] encryptedMessage1 = encrypt(trans.getCardNum(), publicKey);
        String encryptedCardNum = bytesToHex(encryptedMessage1);
        byte[] encryptedMessage2 = encrypt(chuthe, publicKey);
        String encryptedChuthe = bytesToHex(encryptedMessage2);
        byte[] encryptedMessage3 = encrypt(Integer.toString(trans.getID()), publicKey);
        String encryptedID = bytesToHex(encryptedMessage3);
        byte[] encryptedMessage4 = encrypt(trans.getCardnumber(), publicKey);
        String encryptedCardnumber = bytesToHex(encryptedMessage4);
        byte[] encryptedMessage5 = encrypt(trans.getName(), publicKey);
        String encryptedNameth = bytesToHex(encryptedMessage5);
        byte[] encryptedMessage6 = encrypt(Integer.toString(trans.getSodutk()), publicKey);
        String encryptedSodu = bytesToHex(encryptedMessage6);
        byte[] encryptedMessage7 = encrypt(Integer.toString(trans.getSotiengd()), publicKey);
        String encryptedSotiengd = bytesToHex(encryptedMessage7);
        byte[] encryptedMessage8 = encrypt(Integer.toString(trans.getSoduafter()), publicKey);
        String encryptedSoduafter = bytesToHex(encryptedMessage8);
        byte[] encryptedMessage9 = encrypt(date, publicKey);
        String encryptedDate = bytesToHex(encryptedMessage9);
        byte[] encryptedMessage = encrypt(Integer.toString(trans.getCVV()), publicKey);
        String encryptedCVV = bytesToHex(encryptedMessage);
        FileWriter file = new FileWriter("E:\\Documents\\code\\JAVA\\BankJava\\GiaoDich.txt", true);
        BufferedWriter writer = new BufferedWriter(file);
        writer.write(encryptedCardNum + ',' + encryptedChuthe + ',' + encryptedID + ',' + encryptedCardnumber + ',' + encryptedNameth + ',' + encryptedSodu + ',' + encryptedSotiengd + ',' + encryptedSoduafter + ',' + encryptedDate + ',' + encryptedCVV);
        writer.newLine();
        writer.close();
        System.out.println("Xác nhận giao dịch thành công. ");
        System.out.println("Sau đây là thông tin giao dịch của quý khách: ");
        System.out.println("Số thẻ nguồn: " + cardNumber);
        System.out.println("Chủ thẻ: " + chuthe);
        System.out.println("Số dư: " + PrintCurrency(trans.getSodutk()));
        System.out.println("ID giao dịch: " + trans.getID());
        System.out.println("Họ và tên người thụ hưởng: " + trans.getName());
        System.out.println("Số thẻ thụ hưởng: " + trans.getCardnumber());
        System.out.println("Số tiền giao dịch: -" + PrintCurrency(trans.getSotiengd()));
        System.out.println("Số dư sau giao dịch: " + PrintCurrency(trans.getSoduafter()));
        System.out.println("Thời gian giao dịch: " + trans.getDate());
        System.out.println("CVV của chủ thẻ gửi: " + trans.getCVV());
        updateTheFile(cardList, cardNumber, trans.getSoduafter(), publicKey, trans.getCardnumber(), trans.getSotiengd());
    }
    public void HistoryTrans(HistoryTrans history, PrivateKey privateKey) throws IOException{
        ArrayList<HistoryTrans> historyList = readHistoryFile("E:\\Documents\\code\\JAVA\\BankJava\\GiaoDich.txt", privateKey);
        int choose;
        Scanner in = new Scanner(System.in);
        do {
            System.out.println(" ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ LỊCH SỬ GIAO DỊCH ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ");
            if (historyList.isEmpty())
            {
                System.out.println("                                   (Trống)");
                choose = 0;
            }
            else {
                System.out.println(" ------------------ MỜI BẠN CHỌN CÁCH XEM LỊCH SỬ GIAO DỊCH ------------------- ");
                System.out.println(" |              1. XEM TOÀN BỘ LỊCH SỬ GIAO DỊCH                              | ");
                System.out.println(" |              2. XEM LỊCH SỬ GIAO DỊCH THEO ID GIAO DỊCH + SỐ CVV           | ");
                System.out.println(" |              0. THOÁT                                                      | ");
                System.out.println(" ------------------------------------------------------------------------------ ");
                choose = in.nextInt();
                switch (choose) {
                    case 1: {
                        System.out.println(" ------------------ XEM TOÀN BỘ LỊCH SỬ GIAO DỊCH -------------------------- ");
                        for (int i = 0; i < historyList.size(); i++) {
                            System.out.println("BIDV xin thông báo đến quý khách: ");
                            System.out.println("Thời gian giao dịch: " + historyList.get(i).getDate());
                            System.out.println("Số thẻ nguồn: " + historyList.get(i).getCardNum());
                            System.out.println("Chủ thẻ: " + historyList.get(i).getName());
                            System.out.println("Số dư: " + PrintCurrency(historyList.get(i).getSodutk()));
                            System.out.println("ID giao dịch: " + historyList.get(i).getID() + ", CVV của chủ thẻ gửi: " + historyList.get(i).getCVV());
                            System.out.println("Số thẻ thụ hưởng: " + historyList.get(i).getCardnumth() + ", Họ và tên người thụ hưởng: " + historyList.get(i).getNameth());
                            System.out.println("Số tiền giao dịch: -" + PrintCurrency(historyList.get(i).getSotiengd()));
                            System.out.println("Số dư sau giao dịch: " + PrintCurrency(historyList.get(i).getSoduafter()));
                            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                        }
                        in.nextLine();
                        System.out.println("Quay lại Chọn cách Xem lịch sử giao dịch\nNhấn Enter để tiếp tục. ");
                        in.nextLine();
                        break;
                    }
//                    case 2: {
//                        System.out.println(" ----------------- XEM LỊCH SỬ GIAO DỊCH THEO SỐ THẺ ----------------------- ");
//                        String sothe = "";
//                        boolean flag = false;
//                        do {
//                            System.out.println("Mời bạn nhập Số thẻ muốn Xem lịch sử giao dịch: ");
//                            System.out.println("Số thẻ (16 chữ số theo chuẩn thuật toán Luhn): ");
//                            sothe = in.nextLine();
//                        } while (sothe.length() != 16 || (!CheckLuhnAlgorithm1(sothe)));
//                        for (int i = 0; i < historyList.size(); i++) {
//                            if (historyList.get(i).getCardNum() == sothe) {
//                                System.out.println("BIDV xin thông báo đến quý khách: ");
//                                System.out.println("Thời gian giao dịch: " + historyList.get(i).getDate());
//                                System.out.println("Số thẻ nguồn: " + historyList.get(i).getCardNum());
//                                System.out.println("Chủ thẻ: " + historyList.get(i).getName());
//                                System.out.println("Số dư: " + PrintCurrency(historyList.get(i).getSodutk()));
//                                System.out.println("ID giao dịch: " + historyList.get(i).getID() + ", CVV của chủ thẻ gửi: " + historyList.get(i).getCVV());
//                                System.out.println("Số thẻ thụ hưởng: " + historyList.get(i).getCardnumth() + ", Họ và tên người thụ hưởng: " + historyList.get(i).getNameth());
//                                System.out.println("Số tiền giao dịch: -" + PrintCurrency(historyList.get(i).getSotiengd()));
//                                System.out.println("Số dư sau giao dịch: " + PrintCurrency(historyList.get(i).getSoduafter()));
//                                System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//                                flag = true;
//                            }
//                        }
//                        if (flag == false)
//                        {
//                            System.out.println("Số thẻ bạn nhập để Xem lịch sử giao dịch hiện tại chưa có giao dịch. ");
//                        }
//                        in.nextLine();
//                        System.out.println("Quay lại Chọn cách Xem lịch sử giao dịch\nNhấn Enter để tiếp tục. ");
//                        in.nextLine();
//                        break;
//                    }
                    case 2: {
                        System.out.println(" ------------ XEM LỊCH SỬ GIAO DỊCH THEO ID GIAO DỊCH + SỐ CVV ------------- ");
                        int ID = 0, soCvv = 0;
                        boolean flag = false;
                        do {
                            System.out.println("Mời bạn nhập ID Giao dịch và số CVV muốn Xem lịch sử giao dịch: ");
                            System.out.println("ID Giao dịch: ");
                            ID = in.nextInt();
                            in.nextLine();
                            System.out.println("Số CVV (3 chữ số): ");
                            soCvv = in.nextInt();
                        } while (ID < 100000000 || ID > 999999999 || soCvv < 100 || soCvv > 999);
                        for (int i = 0; i < historyList.size(); i++) {
                            if ((historyList.get(i).getID() == ID) && (historyList.get(i).getCVV() == soCvv)) {
                                System.out.println("BIDV xin thông báo đến quý khách: ");
                                System.out.println("Thời gian giao dịch: " + historyList.get(i).getDate());
                                System.out.println("Số thẻ nguồn: " + historyList.get(i).getCardNum());
                                System.out.println("Chủ thẻ: " + historyList.get(i).getName());
                                System.out.println("Số dư: " + PrintCurrency(historyList.get(i).getSodutk()));
                                System.out.println("ID giao dịch: " + historyList.get(i).getID() + ", CVV của chủ thẻ gửi: " + historyList.get(i).getCVV());
                                System.out.println("Số thẻ thụ hưởng: " + historyList.get(i).getCardnumth() + ", Họ và tên người thụ hưởng: " + historyList.get(i).getNameth());
                                System.out.println("Số tiền giao dịch: - " + PrintCurrency(historyList.get(i).getSotiengd()));
                                System.out.println("Số dư sau giao dịch: " + PrintCurrency(historyList.get(i).getSoduafter()));
                                System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                                flag = true;
                            }
                        }
                        if (flag == false)
                        {
                            System.out.println("ID Giao dịch và Số CVV tương ứng bạn nhập để Xem lịch sử giao dịch hiện tại chưa có giao dịch. ");
                        }
                        in.nextLine();
                        System.out.println("Quay lại Chọn cách Xem lịch sử giao dịch\nNhấn Enter để tiếp tục. ");
                        in.nextLine();
                        break;
                    }
                    case 0: {
                        System.out.println(" ~~~~~~~~~~~~~~~~ THOÁT ~~~~~~~~~~~~~~~~~~ ");
                        System.out.println("Đã thoát Xem lịch sử giao dịch tại BIDV. ");
                        break;
                    }
                    default: {
                        System.out.println("Bạn đã lựa chọn không hợp lệ. Vui lòng chọn lại. ");
                        break;
                    }
                }
            }
        } while (choose != 0);
    }
    public void Reseted() throws IOException{
        FileWriter file1 = new FileWriter("E:\\Documents\\code\\JAVA\\BankJava\\The.txt");
        BufferedWriter writer1 = new BufferedWriter(file1);
        writer1.write("");
        writer1.close();

        FileWriter file2 = new FileWriter("E:\\Documents\\code\\JAVA\\BankJava\\GiaoDich.txt");
        BufferedWriter writer2 = new BufferedWriter(file2);
        writer2.write("");
        writer2.close();
    }
}

