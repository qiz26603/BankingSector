import java.io.*;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Function {
    public static ArrayList<CheckLog> readCheckLogFile(String filename) {
        ArrayList<CheckLog> UsersList = new ArrayList<>();
        try (BufferedReader bfr = new BufferedReader(new FileReader(filename))){
            String line;
            while ((line = bfr.readLine()) != null) {
                String[] data = line.split(",");
                String Stk = data[0];
                String pass = data[1];
                String name = data[2];
                int sodu = Integer.parseInt(data[3]);
                CheckLog user = new CheckLog(Stk, pass, name, sodu);
                UsersList.add(user);
            }
            bfr.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return UsersList;
    }
    public static void updateTheFile(ArrayList<CheckLog> UsersList, String Stk, int Soduafter) throws Exception {
        FileWriter file = new FileWriter("E:\\Documents\\code\\JAVA\\ATM Withdraw\\Stk.txt");
        BufferedWriter writer3 = new BufferedWriter(file);
        writer3.write("");
        writer3.close();
        for (int i = 0; i < UsersList.size(); i++) {
            if (UsersList.get(i).getStk().equals(Stk)) {
                UsersList.get(i).setSodu(Soduafter);
            }
        }
        for (int i = 0; i < UsersList.size(); i++) {
            FileWriter file1 = new FileWriter("E:\\Documents\\code\\JAVA\\ATM Withdraw\\Stk.txt", true);
            BufferedWriter writer = new BufferedWriter(file1);
            writer.write(UsersList.get(i).getStk() + ',' + UsersList.get(i).getPassword() + ',' + UsersList.get(i).getName() + ',' + UsersList.get(i).getSodu());
            writer.newLine();
            writer.close();
        }
    }
    public static String PrintCurrency(int money)
    {
        String moneystring = String.valueOf(money);
        StringBuilder sb = new StringBuilder(moneystring);
        int comma = 0, locate = 0;
        comma = (moneystring.length() - 1)/3;
        locate = moneystring.length() - comma * 3;
        while (comma > 0)
        {
            sb = sb.insert(locate, ",");
            locate += 4;
            comma --;
        }
        moneystring = sb.toString();
        return moneystring + " VND";
    }
    public static boolean CheckUsersLog(ArrayList<CheckLog> UsersList, String Stk, String Pass) throws IOException {
        boolean log = true;
        boolean flag = false;
        try {
            for (int i = 0; i < UsersList.size(); i++)
            {
                CheckLog user = UsersList.get(i);
                if (user.getStk().equals(Stk))
                {
                    if (user.getPassword().equals(Pass))
                    {
                        System.out.println("Số tài khoản: " + Stk);
                        System.out.println("Chủ tài khoản: " + user.getName());
                        System.out.println("Số dư: " + PrintCurrency(user.getSodu()));
                        log = true;
                        flag = true;
                        break;
                    }
                    else
                    {
                        throw new ATMUserLog("Bạn đã nhập Sai mật khẩu để rút tiền. Vui lòng kiểm tra và nhập lại Stk và mật khẩu. ", 102);
                    }
                }
                else {
                    continue;
                }
            }
            if (!flag)
            {
                throw new ATMUserLog("Bạn đã nhập Sai số tài khoản để rút tiền. Vui lòng kiểm tra và nhập lại. ", 101);
            }
        } catch (ATMUserLog e)
        {
            log = false;
            System.out.println(e.getMessage());
            Date day = new Date();
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy; HH:mm:ss");
            String date = df.format(day);
            FileWriter file = new FileWriter("E:\\Documents\\code\\JAVA\\ATM Withdraw\\WriteLog.txt",true);
            BufferedWriter writer3 = new BufferedWriter(file);
            writer3.write(date + ',' +e.getMessage());
            writer3.newLine();
            writer3.close();
        }
        return log;
    }
    public static boolean CheckWithDraw(ArrayList<CheckLog> UsersList, String Stk, int money) throws IOException {
        int sodu = 0;
        String name = "";
        for (int i = 0; i < UsersList.size(); i++)
        {
            CheckLog user = UsersList.get(i);
            if (user.getStk().equals(Stk)) {
                name = user.getName();
                sodu = user.getSodu();
            }
        }
        boolean flag = true;
        try{
            if ((money % 10000) != 0) {
                throw new ATMWithDraw("Số tiền bạn rút ra không phải là bội số của 10,000 VND ", 100);
            }
            else if ((sodu - money) < 0 || (sodu - money) == 0)
            {
                throw new ATMWithDraw("Số dư không đủ để rút tiền. Vui lòng kiểm tra lại. ", 103)   ;
            }
            else
            {
                System.out.println("Giao dịch rút tiền thành công: ");
                System.out.println("Số tài khoản: " + Stk);
                System.out.println("Chủ tài khoản: " + name);
                System.out.println("Số dư: " + PrintCurrency(sodu));
                System.out.println("Số tiền rút: " + PrintCurrency(money));
                int soduconlai = sodu - money;
                System.out.println("Số tiền còn lại trong tài khoản " + Stk + " là: " + PrintCurrency(soduconlai));
                updateTheFile(UsersList, Stk, soduconlai);
                Date day = new Date();
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy; HH:mm:ss");
                String date = df.format(day);
                FileWriter file = new FileWriter("E:\\Documents\\code\\JAVA\\ATM Withdraw\\WriteLog.txt",true);
                BufferedWriter writer3 = new BufferedWriter(file);
                writer3.write(date + ',' + Stk + ',' + name + ',' + sodu + ',' + money + ',' + soduconlai);
                writer3.newLine();
                writer3.close();
                flag = true;
            }
        } catch (ATMWithDraw e)
        {
            flag = false;
            System.out.println(e.getMessage());
            Date day = new Date();
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy; HH:mm:ss");
            String date = df.format(day);
            FileWriter file = new FileWriter("E:\\Documents\\code\\JAVA\\ATM Withdraw\\WriteLog.txt",true);
            BufferedWriter writer3 = new BufferedWriter(file);
            writer3.write(date + ',' + e.getMessage());
            writer3.newLine();
            writer3.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return flag;
    }
    public void WithdrawMoney() throws IOException {
        ArrayList<CheckLog> UsersList = readCheckLogFile("E:\\Documents\\code\\JAVA\\ATM Withdraw\\Stk.txt");
        String stk = "", pass = "";
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("Mời bạn nhập vào stk: ");
            stk = input.nextLine();
            System.out.println("Mời bạn nhập vào mật khẩu: ");
            pass = input.nextLine();
        } while (!CheckUsersLog(UsersList, stk, pass));
        System.out.println("Đã đăng nhập thành công. ");
        int tien = 0;
        do {
            System.out.println("Mời bạn nhập số tiền muốn rút: ");
            tien = input.nextInt();
        } while (!CheckWithDraw(UsersList, stk, tien));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }
}
