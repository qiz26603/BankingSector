public class CheckLog {
    private String stk = "", password = "", name = "";
    private int sodu = 0;
    public CheckLog(String stk, String password, String name, int sodu)
    {
        this.stk = stk;
        this.password = password;
        this.name = name;
        this.sodu = sodu;
    }
    public String getStk() {
        return stk;
    }
    public void setStk(String stk) {
        this.stk = stk;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSodu() {
        return sodu;
    }
    public void setSodu(int sodu) {
        this.sodu = sodu;
    }
}
