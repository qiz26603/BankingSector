public class ATMUserLog extends Exception {
        private int errorCode;
        public ATMUserLog(String message, int errorCode) {
            super(message + ",Error Code: " + Integer.toString(errorCode));
            this.errorCode = errorCode;
        }
        public int getErrorCode() {
            return errorCode;
        }
}
