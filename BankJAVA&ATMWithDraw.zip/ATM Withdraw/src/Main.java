import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        CheckLog user = new CheckLog("","","",0);
        Function load = new Function();
        System.out.println("RÚT TIỀN TẠI ATM");
        load.WithdrawMoney();
    }
}